# RAG Chat App (Flask backend + HTML/CSS/JS frontend)
Supports uploading .txt and .pdf files, builds embeddings with OpenAI, stores in ChromaDB, and answers questions via Retrieval-Augmented Generation (RAG).

## Requirements
- Python 3.11.x (you said 3.11.5)
- OpenAI API key (set as environment variable OPENAI_API_KEY)

## Setup (VS Code terminal)
1. Open project folder in VS Code
2. Create & activate a virtual environment:
   - `python -m venv venv`
   - Windows: `venv\\Scripts\\activate`
   - macOS/Linux: `source venv/bin/activate`
3. Install dependencies:
   - `cd backend`
   - `pip install -r requirements.txt`
4. Set your OpenAI API key:
   - Windows: `setx OPENAI_API_KEY "your_api_key_here"` (then restart VS Code)
   - macOS/Linux: `export OPENAI_API_KEY=your_api_key_here`
5. Run the backend:
   - `python app.py`
6. Open browser to: `http://127.0.0.1:5000`

## Notes
- This project uses `langchain` and `chromadb` for embeddings+vector store.
- In production, do not run Flask with `debug=True`. Use a proper WSGI server.
- You can extend storage of the vector DB to disk or use an external vector DB (Pinecone, Weaviate, etc.).