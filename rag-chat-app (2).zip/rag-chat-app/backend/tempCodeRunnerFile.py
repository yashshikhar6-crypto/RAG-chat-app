
        messages=[{"role": "user", "content": "Hello Groq!"}]
    )