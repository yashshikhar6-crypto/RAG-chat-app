"""
inspect_vectors.py
-------------------
Standalone script to inspect your FAISS vector database created by the RAG app.
It loads your uploaded documents, prints stored text chunks, and visualizes embeddings.
"""

import os
import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

# Path to your uploads folder and vector store
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(APP_ROOT, "uploads")

print("=" * 60)
print("🔍 FAISS VECTOR STORE INSPECTOR")
print("=" * 60)

# --- Load embeddings (same as your app) ---
print("Loading embeddings model...")
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# --- Check for uploaded files ---
if not os.path.exists(UPLOAD_FOLDER):
    print("❌ No uploads folder found.")
    exit()

uploaded_files = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith(('.txt', '.pdf'))]
if not uploaded_files:
    print("❌ No uploaded files found in:", UPLOAD_FOLDER)
    exit()

print(f"Found {len(uploaded_files)} uploaded file(s):")
for f in uploaded_files:
    print(" -", f)

# --- Optional: Recreate FAISS store (you can skip this if your app runs it) ---
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
import fitz

def extract_text_from_pdf(path):
    text = []
    with fitz.open(path) as doc:
        for page in doc:
            text.append(page.get_text())
    return "\n".join(text)

filename = uploaded_files[0]
filepath = os.path.join(UPLOAD_FOLDER, filename)

if filename.lower().endswith(".pdf"):
    print(f"\nExtracting text from {filename} (PDF)...")
    text = extract_text_from_pdf(filepath)
else:
    print(f"\nReading text from {filename} (TXT)...")
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()

splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
chunks = splitter.split_text(text)
documents = [Document(page_content=chunk) for chunk in chunks]
print(f"✅ Split into {len(chunks)} text chunks")

# --- Create FAISS vector store ---
print("Creating FAISS index...")
db = FAISS.from_documents(documents, embeddings)
print("✅ FAISS store created successfully!\n")

# --- Inspect stored data ---
print("=" * 60)
print("📚 VECTOR STORE DETAILS")
print("=" * 60)
print("Total chunks stored:", len(db.index_to_docstore_id))
print()

for i, doc_id in enumerate(db.index_to_docstore_id.values()):
    doc = db.docstore.search(doc_id)
    print(f"Chunk {i+1}: {len(doc.page_content)} chars")
    print(doc.page_content[:150].replace("\n", " "), "...\n")

# --- Optional: Visualize embeddings ---
# --- Optional: Visualize embeddings ---
print("=" * 60)
print("🧭 VISUALIZING EMBEDDINGS")
print("=" * 60)

X = [embeddings.embed_query(d.page_content) for d in documents[:50]]  # limit to 50 for speed
X = np.array(X)
print("Embedding dimension:", X.shape[1])

if len(X) < 2:
    print("⚠️ Not enough chunks to visualize (need at least 2).")
    print("Only 1 text chunk found — try uploading a larger document.")
else:
    # Reduce to 2D using PCA
    pca = PCA(n_components=2)
    reduced = pca.fit_transform(X)

    plt.figure(figsize=(6, 5))
    plt.scatter(reduced[:, 0], reduced[:, 1], alpha=0.7, c="dodgerblue")
    plt.title("2D projection of document embeddings")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.show()

    print("\n✅ Visualization complete.")
